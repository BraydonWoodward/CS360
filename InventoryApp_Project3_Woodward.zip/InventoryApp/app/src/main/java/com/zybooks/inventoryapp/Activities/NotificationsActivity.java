package com.zybooks.inventoryapp.Activities;

import android.app.Activity;

public class NotificationsActivity extends Activity {
}
