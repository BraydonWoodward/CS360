package com.zybooks.inventoryapp.Activities;

import android.app.Activity;

public class ItemDataActivity extends Activity {
}
