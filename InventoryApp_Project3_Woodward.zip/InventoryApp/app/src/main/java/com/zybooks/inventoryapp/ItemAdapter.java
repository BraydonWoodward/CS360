package com.zybooks.inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryapp.Dialogs.UpdateItemDialog;

/**
 * Adapter class for displaying items in a RecyclerView.
 * Binds data from a Cursor to the views in each item of the RecyclerView.
 */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private final Context context; // Context for inflating layouts and accessing resources
    private Cursor cursor;   // Cursor to query and retrieve item data from the database
    private final OnDeleteClickListener onDeleteClickListener; // Listener for delete actions
    private final OnUpdateClickListener onUpdateClickListener; // Listener for update actions

    /**
     * Interface to handle delete button clicks.
     */
    public interface OnDeleteClickListener {
        void onDeleteClick(int itemId); // Method to handle delete action
    }

    /**
     * Interface to handle update button clicks.
     */
    public interface OnUpdateClickListener {
        void onUpdateClick(long itemId, int quantity); // Method to handle update action
    }

    /**
     * Constructor for ItemAdapter.
     *
     * @param context              Context for resource access and layout inflation
     * @param cursor               Cursor to fetch item data from the database
     * @param onDeleteClickListener Listener to handle delete actions
     * @param onUpdateClickListener Listener to handle update actions
     */
    public ItemAdapter(Context context, Cursor cursor, OnDeleteClickListener onDeleteClickListener, OnUpdateClickListener onUpdateClickListener) {
        this.context = context;
        this.cursor = cursor;
        this.onDeleteClickListener = onDeleteClickListener;
        this.onUpdateClickListener = onUpdateClickListener;
    }

    /**
     * Swaps the current cursor with a new one.
     * Closes the previous cursor if it exists and updates the RecyclerView.
     *
     * @param newCursor The new cursor to be used
     */
    public void swapCursor(Cursor newCursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        cursor = newCursor;
        if (newCursor != null) {
            notifyDataSetChanged();
        }
    }

    /**
     * Creates and returns a new ViewHolder instance.
     * Inflates the layout for each item in the RecyclerView.
     *
     * @param parent   The parent view that this ViewHolder will be attached to
     * @param viewType The view type of the new ViewHolder
     * @return A new ViewHolder instance
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout and create a new ViewHolder
        View view = LayoutInflater.from(context).inflate(R.layout.activity_item_data, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Returns the total number of items in the cursor.
     *
     * @return The number of items in the cursor
     */
    @Override
    public int getItemCount() {
        return cursor != null ? cursor.getCount() : 0;
    }

    /**
     * Binds data from the cursor to the views in the ViewHolder.
     * Updates the views with the current item data.
     *
     * @param holder   The ViewHolder that will hold the item views
     * @param position The position of the item in the cursor
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Move cursor to the correct position
        if (cursor.moveToPosition(position)) {
            // Retrieve item data from the cursor
            long itemId = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));

            // Set item data to the views
            holder.itemName.setText(itemName);
            holder.itemQuantity.setText(String.format(context.getString(R.string.quantity_item_adapter), quantity));

            // Handle delete button click
            holder.deleteButton.setOnClickListener(v -> {
                if (onDeleteClickListener != null) {
                    onDeleteClickListener.onDeleteClick((int) itemId);
                }
            });

            // Set up the update button
            holder.updateButton.setOnClickListener(v -> {
                // Instantiate and show the dialog
                UpdateItemDialog dialog = UpdateItemDialog.newInstance(itemId, itemName, quantity);
                dialog.show(((FragmentActivity) context).getSupportFragmentManager(), "UpdateItemDialog");
            });
        }
    }

    /**
     * ViewHolder class to hold references to the views in each item.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName; // TextView for displaying the item name
        public TextView itemQuantity; // TextView for displaying the item quantity
        public Button deleteButton; // Button for deleting an item
        public Button updateButton; // Button for updating an item

        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteItemButton);
            updateButton = itemView.findViewById(R.id.updateItemButton);
        }
    }
}
