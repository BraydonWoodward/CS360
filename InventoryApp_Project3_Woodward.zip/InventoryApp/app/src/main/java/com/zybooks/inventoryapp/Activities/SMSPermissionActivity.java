package com.zybooks.inventoryapp.Activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.zybooks.inventoryapp.R;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private TextView notificationStatus;
    private Button requestPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        notificationStatus = findViewById(R.id.notificationStatus);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);

        // Set up the request permission button listener
        requestPermissionButton.setOnClickListener(v -> checkForSMSPermission());

        // Handle back press using OnBackPressedDispatcher
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Do something when the back button is pressed
                finish(); // Finish the activity or handle any custom back navigation
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);

        // Check if permission is already granted
        if (isSMSPermissionGranted()) {
            notificationStatus.setText(R.string.notifications_enabled);
        } else {
            notificationStatus.setText(R.string.notifications_disabled);
        }
    }

    private void checkForSMSPermission() {
        if (!isSMSPermissionGranted()) {
            // Request SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission is already granted
            notificationStatus.setText(R.string.notifications_enabled);
        }
    }

    private boolean isSMSPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                notificationStatus.setText(R.string.notifications_enabled);
                // Handle SMS sending logic here
            } else {
                notificationStatus.setText(R.string.notifications_disabled);
            }
        }
    }
}
