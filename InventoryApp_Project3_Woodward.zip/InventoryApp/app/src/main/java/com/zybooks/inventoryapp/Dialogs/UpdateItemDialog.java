package com.zybooks.inventoryapp.Dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.zybooks.inventoryapp.Activities.DataDisplayActivity;
import com.zybooks.inventoryapp.R;

/**
 * A DialogFragment for updating item details.
 * <p>
 * This dialog allows users to update the name and quantity of an item.
 * It uses arguments to pass the current item details to the dialog.
 * </p>
 */
public class UpdateItemDialog extends DialogFragment {

    // Argument keys for passing item details to the dialog
    private static final String ARG_ITEM_ID = "item_id";
    private static final String ARG_ITEM_NAME = "item_name";
    private static final String ARG_ITEM_QUANTITY = "item_quantity";

    // Variables to hold item details
    private long itemId;
    private String itemName;
    private int quantity;

    /**
     * Factory method to create a new instance of UpdateItemDialog.
     *
     * @param itemId      The ID of the item to be updated.
     * @param itemName    The current name of the item.
     * @param quantity    The current quantity of the item.
     * @return A new instance of UpdateItemDialog.
     */
    public static UpdateItemDialog newInstance(long itemId, String itemName, int quantity) {
        UpdateItemDialog dialog = new UpdateItemDialog();
        Bundle args = new Bundle();
        args.putLong(ARG_ITEM_ID, itemId);
        args.putString(ARG_ITEM_NAME, itemName);
        args.putInt(ARG_ITEM_QUANTITY, quantity);
        dialog.setArguments(args);
        return dialog;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Retrieve arguments from the bundle
        if (getArguments() != null) {
            itemId = getArguments().getLong(ARG_ITEM_ID);
            itemName = getArguments().getString(ARG_ITEM_NAME);
            quantity = getArguments().getInt(ARG_ITEM_QUANTITY);
        }

        // Inflate the dialog layout
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_update_item, null);

        // Initialize input fields with current item data

        EditText quantityEditText = view.findViewById(R.id.editTextItemQuantity);
        quantityEditText.setText(itemName);
        quantityEditText.setText(String.valueOf(quantity));

        // Set up the dialog
        builder.setView(view)
                .setTitle("Update Item")
                .setPositiveButton("Update", (dialog, id) -> {
                    // Handle update action
                    int newQuantity;
                    try {
                        newQuantity = Integer.parseInt(quantityEditText.getText().toString());
                    } catch (NumberFormatException e) {
                        newQuantity = 0; // Default value or handle error
                    }
                    // Update the item using the DataDisplayActivity
                    ((DataDisplayActivity) requireActivity()).updateItem(itemId, newQuantity);
                })
                .setNegativeButton("Cancel", (dialog, id) -> {
                    // Handle cancel action
                    dialog.dismiss();
                });

        return builder.create();
    }
}