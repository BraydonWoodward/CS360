package com.zybooks.inventoryapp;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * DatabaseHelper is a helper class that manages database creation, version management,
 * and CRUD operations for the Inventory App.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Name and Version
    private static final String DATABASE_NAME = "inventoryApp.db";
    private static final int DATABASE_VERSION = 1;

    // Table Names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_INVENTORY_ITEMS = "inventory_items";

    // Columns for Users Table
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Columns for Inventory Items Table
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_CATEGORY = "category";
    public static final String COLUMN_ADDED_BY_USER_ID = "added_by_user_id";

    // SQL statement to create Users Table
    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT);";

    // SQL statement to create Inventory Items Table
    private static final String TABLE_CREATE_INVENTORY_ITEMS =
            "CREATE TABLE " + TABLE_INVENTORY_ITEMS + " (" +
                    COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT, " +
                    COLUMN_QUANTITY + " INTEGER, " +
                    COLUMN_CATEGORY + " TEXT, " +
                    COLUMN_ADDED_BY_USER_ID + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_ADDED_BY_USER_ID + ") REFERENCES " +
                    TABLE_USERS + "(" + COLUMN_ID + "));";

    /**
     * Constructor for DatabaseHelper.
     * @param context The context in which the database is being accessed.
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time.
     * This method is responsible for creating the necessary tables for the application.
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Execute SQL statements to create the tables
        db.execSQL(TABLE_CREATE_USERS);
        db.execSQL(TABLE_CREATE_INVENTORY_ITEMS);
    }

    /**
     * Called when the database needs to be upgraded.
     * This method will drop the existing tables and recreate them if the database version is updated.
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Log upgrade details for debugging
        Log.w(DatabaseHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");

        // Drop existing tables and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY_ITEMS);
        onCreate(db);
    }

    // Add methods for managing inventory items (CRUD operations) as needed...
}
