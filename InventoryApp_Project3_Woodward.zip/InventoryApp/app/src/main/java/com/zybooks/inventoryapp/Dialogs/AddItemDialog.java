package com.zybooks.inventoryapp.Dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.zybooks.inventoryapp.Activities.DataDisplayActivity;
import com.zybooks.inventoryapp.R;

/**
 * DialogFragment for adding a new item to the inventory.
 * Provides input fields for the item name and quantity, and a save button.
 */
public class AddItemDialog extends DialogFragment {

    private EditText editTextItemName;
    private EditText editTextItemQuantity;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        View view = inflater.inflate(R.layout.dialog_add_item, null);
        editTextItemName = view.findViewById(R.id.editTextItemName);
        editTextItemQuantity = view.findViewById(R.id.editTextItemQuantity);

        builder.setView(view)
                .setTitle("Add New Item")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        saveItem();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss(); // User cancelled the dialog
                    }
                });

        return builder.create();
    }

    /**
     * Validates the input and adds a new item to the database.
     */
    private void saveItem() {
        String itemName = editTextItemName.getText().toString().trim();
        String itemQuantityStr = editTextItemQuantity.getText().toString().trim();

        if (TextUtils.isEmpty(itemName)) {
            showToast("Item name cannot be empty");
            return;
        }

        if (TextUtils.isEmpty(itemQuantityStr)) {
            showToast("Item quantity cannot be empty");
            return;
        }

        int itemQuantity;
        try {
            itemQuantity = Integer.parseInt(itemQuantityStr);
        } catch (NumberFormatException e) {
            showToast("Invalid quantity");
            return;
        }

        DataDisplayActivity activity = (DataDisplayActivity) getActivity();
        if (activity != null) {
            activity.addItem(itemName, itemQuantity);
            dismiss(); // Close the dialog after saving the item
        } else {
            showToast("Unable to add item, activity is not available");
        }
    }

    /**
     * Helper method to show a Toast message.
     *
     * @param message The message to display in the Toast.
     */
    private void showToast(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }
}
