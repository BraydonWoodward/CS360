package com.zybooks.inventoryapp.Activities;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryapp.DatabaseHelper;
import com.zybooks.inventoryapp.Dialogs.AddItemDialog;
import com.zybooks.inventoryapp.ItemAdapter;
import com.zybooks.inventoryapp.R;

/**
 * Activity for displaying inventory items in a grid layout.
 * Allows users to view, add, and manage inventory items.
 */
public class DataDisplayActivity extends AppCompatActivity implements ItemAdapter.OnDeleteClickListener, ItemAdapter.OnUpdateClickListener {

    private static final int SMS_PERMISSION_CODE = 1001;
    private static final int LOW_QUANTITY_THRESHOLD = 10; // Set your threshold here

    private RecyclerView recyclerView;      // RecyclerView to display items in a grid
    private DatabaseHelper dbHelper;        // Helper class for database operations
    private Cursor cursor;                  // Cursor for database query

    /**
     * Called when the activity is first created.
     * Initializes the database helper, sets up the RecyclerView,
     * loads data from the database, and checks for SMS permission.
     *
     * @param savedInstanceState If the activity is being reinitialized after previously being shut down,
     *                           this Bundle contains the data it most recently supplied in onSaveInstanceState(Bundle).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize DatabaseHelper for database operations
        dbHelper = new DatabaseHelper(this);

        // Setup RecyclerView with GridLayoutManager for displaying items in a grid
        recyclerView = findViewById(R.id.dataRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 1)); // Display items in 1 column

        // Load data from the database and set up the adapter
        loadData();

        // Setup the button to add a new item
        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(v -> {
            // Show the AddItemDialog fragment to add a new item
            showAddItemDialog();
        });

        // Check for SMS permission when the activity is created
        checkForSMSPermission();
    }

    /**
     * Checks if SMS permission is granted, and requests it if not.
     */
    private void checkForSMSPermission() {
        if (!isSMSPermissionGranted()) {
            // Request SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission is already granted, you can proceed with SMS-related tasks
            Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Checks whether the SMS permission is granted.
     *
     * @return true if granted, false otherwise.
     */
    private boolean isSMSPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Handles the result of the SMS permission request.
     *
     * @param requestCode  The request code passed in requestPermissions().
     * @param permissions  The requested permissions.
     * @param grantResults The results for the corresponding permissions.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can proceed with SMS-related tasks
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied, notify the user
                Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Sends an SMS alert when an inventory item quantity is below a threshold.
     *
     * @param itemName The name of the item.
     * @param itemQuantity The quantity of the item.
     */
    private void sendLowInventoryAlert(String itemName, int itemQuantity) {
        if (isSMSPermissionGranted()) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String message = "Low inventory alert: " + itemName + " is below the threshold. Current quantity: " + itemQuantity;
                String phoneNumber = "1234567890"; // Replace with the desired phone number
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS sent for low inventory: " + itemName, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Shows the AddItemDialog to add a new item.
     */
    private void showAddItemDialog() {
        AddItemDialog dialog = new AddItemDialog();
        dialog.show(getSupportFragmentManager(), "AddItemDialog");
    }


    /**
     * Loads data from the database and sets up the RecyclerView adapter.
     * Queries the database for all inventory items and populates the RecyclerView with the data.
     */
    private void loadData() {
        SQLiteDatabase db;

        try {
            db = dbHelper.getReadableDatabase();

            cursor = db.query(
                    DatabaseHelper.TABLE_INVENTORY_ITEMS,
                    null,
                    null,
                    null,
                    null,
                    null,
                    null);

            ItemAdapter itemAdapter = new ItemAdapter(this, cursor, this, this);
            recyclerView.setAdapter(itemAdapter);

        } catch (Exception e) {
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Adds a new item to the database.
     *
     * @param itemName The name of the item to add.
     * @param itemQuantity The quantity of the item to add.
     */
    public void addItem(String itemName, int itemQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, itemName);
        values.put(DatabaseHelper.COLUMN_QUANTITY, itemQuantity);

        long newRowId = db.insert(DatabaseHelper.TABLE_INVENTORY_ITEMS, null, values);

        if (newRowId != -1) {
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
            loadData();
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Updates an existing item in the database.
     *
     * @param itemId The ID of the item to update.
     * @param newItemQuantity The new quantity for the item.
     */
    public void updateItem(long itemId, int newItemQuantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_QUANTITY, newItemQuantity);

        int rowsAffected = db.update(
                DatabaseHelper.TABLE_INVENTORY_ITEMS,
                values,
                DatabaseHelper.COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        if (rowsAffected > 0) {
            Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();

            // Check if the item quantity is below the threshold and send an SMS alert if needed
            if (newItemQuantity < LOW_QUANTITY_THRESHOLD) {
                sendLowInventoryAlert(getItemNameById(itemId), newItemQuantity);
            }

            loadData();
        } else {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Deletes an item from the database.
     *
     * @param itemId The ID of the item to delete.
     */
    @Override
    public void onDeleteClick(int itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsAffected = db.delete(
                DatabaseHelper.TABLE_INVENTORY_ITEMS,
                DatabaseHelper.COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        if (rowsAffected > 0) {
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            loadData();
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Retrieves the name of an item by its ID.
     *
     * @param itemId The ID of the item.
     * @return The name of the item.
     */
    private String getItemNameById(long itemId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String itemName = null;

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_INVENTORY_ITEMS,
                new String[]{DatabaseHelper.COLUMN_ITEM_NAME},
                DatabaseHelper.COLUMN_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)},
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
            cursor.close();
        }

        return itemName;
    }

    @Override
    public void onUpdateClick(long itemId, int newQuantity) {
        updateItem(itemId, newQuantity);
    }
}





