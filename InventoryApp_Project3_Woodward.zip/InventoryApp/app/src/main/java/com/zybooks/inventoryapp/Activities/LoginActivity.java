package com.zybooks.inventoryapp.Activities;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventoryapp.DatabaseHelper;
import com.zybooks.inventoryapp.R;

/**
 * LoginActivity handles user authentication, including login and account creation.
 * It interacts with the SQLite database to verify credentials and manage user accounts.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText nameText;         // EditText for entering username
    private EditText passwordText;     // EditText for entering password
    private DatabaseHelper dbHelper;   // Helper class to manage database operations

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI elements
        nameText = findViewById(R.id.nameText);
        passwordText = findViewById(R.id.passwordText);
        Button loginButton = findViewById(R.id.login);
        Button createNewAccountButton = findViewById(R.id.createNewAccount);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Set up listeners for buttons
        loginButton.setOnClickListener(v -> handleLogin());
        createNewAccountButton.setOnClickListener(v -> handleCreateNewAccount());
    }

    /**
     * Handles user login by validating credentials against the database.
     */
    private void handleLogin() {
        // Retrieve input from EditTexts
        String username = nameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Query the database for matching username and password
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COLUMN_ID},
                DatabaseHelper.COLUMN_USERNAME + "=? AND " + DatabaseHelper.COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        // Check if credentials are valid
        if (cursor != null && cursor.moveToFirst()) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            cursor.close();

            //Proceed to the next screen (e.g., Inventory screen)
            Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

        // Close cursor to avoid memory leaks
        if (cursor != null) {
            cursor.close();
        }
    }

    /**
     * Handles the creation of a new user account by inserting data into the database.
     */
    private void handleCreateNewAccount() {
        // Retrieve input from EditTexts
        String username = nameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if username already exists
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COLUMN_ID},
                DatabaseHelper.COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        // Handle the case where username already exists
        if (cursor != null && cursor.moveToFirst()) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            cursor.close();
        } else {
            // Username is available; proceed to create a new account
            if (cursor != null) {
                cursor.close();
            }

            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_USERNAME, username);
            values.put(DatabaseHelper.COLUMN_PASSWORD, password);

            // Insert new user into the database
            long newRowId = db.insert(DatabaseHelper.TABLE_USERS, null, values);

            if (newRowId != -1) {
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                // Optionally, log the user in automatically
                // handleLogin();
            } else {
                Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        }
    }
}